import React, { Component } from "react"

class Boton extends Component {
    render() {
        return (
            <div className="divRepartir">
                <button>Repartir Cartas</button>
            </div>
        )
    }
}

export default Boton
